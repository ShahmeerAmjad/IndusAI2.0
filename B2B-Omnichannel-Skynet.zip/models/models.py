import html
from typing import List
from pydantic import BaseModel, ConfigDict, Field, validator
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

# =======================
# Data Models
# =======================

class MessageType(Enum):
    ORDER_STATUS = "order_status"
    PRODUCT_INQUIRY = "product_inquiry"
    TECHNICAL_SUPPORT = "technical_support"
    GENERAL_QUERY = "general_query"
    UNKNOWN = "unknown"

class ChannelType(Enum):
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    WEB = "web"

@dataclass
class CustomerMessage:
    id: str
    from_id: str
    content: str
    channel: ChannelType
    timestamp: datetime
    message_type: MessageType = MessageType.UNKNOWN
    confidence: float = 0.0

@dataclass
class BotResponse:
    content: str
    suggested_actions: List[str] = field(default_factory=list)
    escalate: bool = False

# =======================
# Request/Response Models
# =======================

class MessageRequest(BaseModel):
    from_id: str = Field(..., min_length=1, max_length=100, pattern=r'^[a-zA-Z0-9_\-@\+]+$')
    content: str = Field(..., min_length=1, max_length=1000)
    channel: str = Field(default="web", pattern='^(whatsapp|email|web)$')
    
    @validator('content')
    def sanitize_content(cls, v):
        # Basic XSS prevention
        return html.escape(v)
    
    @validator('from_id')
    def validate_from_id(cls, v):
        # Additional validation for from_id
        if any(char in v for char in ['<', '>', '"', "'", '&']):
            raise ValueError("Invalid characters in from_id")
        return v