# =======================
# Main Chatbot Engine
# =======================

import asyncio
from datetime import datetime, timezone
import time
import uuid
from metrics.metrics import ACTIVE_SESSIONS, ERROR_COUNTER, MESSAGES_TOTAL, RESPONSE_TIME
from models.models import BotResponse, ChannelType, CustomerMessage
from typing import Optional

class ChatbotEngine:
    def __init__(self, classifier, logger, business_logic, db_manager):
        self.classifier = classifier
        self.logger = logger
        self.business_logic = business_logic
        self.db_manager = db_manager

    async def process_message(self, from_id: str, content: str, channel: ChannelType) -> Optional[BotResponse]:
        """Main message processing pipeline"""
        start_time = time.time()
        
        try:
            # Validate input length
            if len(content) < 2:
                return BotResponse(
                    content="Please provide more details so I can better assist you.",
                    suggested_actions=["Get help", "Contact support"]
                )
            
            # Create message object
            message = CustomerMessage(
                id=str(uuid.uuid4()),
                from_id=from_id,
                content=content,
                channel=channel,
                timestamp=datetime.now(timezone.utc)
            )
            
            # Update active sessions metric
            ACTIVE_SESSIONS.inc()
            
            # Classify intent
            message_type, confidence = self.classifier.classify(content)
            message.message_type = message_type
            message.confidence = confidence
            
            # Log low confidence classifications
            if confidence < 0.5:
                self.logger.warning(f"Low confidence classification: {confidence} for message: {content[:50]}...")
            
            # Generate response
            response = await self.business_logic.process_message(message)
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Update metrics
            MESSAGES_TOTAL.labels(message_type=message_type.value, channel=channel.value).inc()
            RESPONSE_TIME.observe(response_time)
            
            # Save to database (non-blocking)
            asyncio.create_task(self.db_manager.save_message(message, response, response_time))
            
            # Decrement active sessions
            ACTIVE_SESSIONS.dec()
            
            return response
        
        except Exception as e:
            self.logger.error(f"Message processing error: {e}")
            ERROR_COUNTER.labels(error_type="message_processing").inc()
            ACTIVE_SESSIONS.dec()
            
            return BotResponse(
                content="I apologize, but I encountered an error processing your request. Please try again or contact our support team at support@company.com.",
                suggested_actions=["Try again", "Contact support", "Call us"]
            )
