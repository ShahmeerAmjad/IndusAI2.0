# =======================
# Business Logic
# =======================

import re
from typing import Dict
from models.models import BotResponse, CustomerMessage, MessageType


class BusinessLogic:
    def __init__(self, db_manager, ai_service):
        self.db_manager = db_manager
        self.ai_service = ai_service

    async def process_message(self, message: CustomerMessage) -> BotResponse:
        """Process customer message and generate response"""
        
        # Get customer session for context
        session = await self.db_manager.get_customer_session(message.from_id)
        context = session or {"message_count": 0}
        context["message_count"] += 1
        
        # Route to appropriate handler
        if message.message_type == MessageType.ORDER_STATUS:
            response = await self._handle_order_status(message, context)
        elif message.message_type == MessageType.PRODUCT_INQUIRY:
            response = await self._handle_product_inquiry(message, context)
        elif message.message_type == MessageType.TECHNICAL_SUPPORT:
            response = await self._handle_technical_support(message, context)
        else:
            response = await self._handle_general_query(message, context)
        
        # Save updated session
        await self.db_manager.save_customer_session(message.from_id, context)
        
        return response
    
    async def _handle_order_status(self, message: CustomerMessage, context: Dict) -> BotResponse:
        """Handle order status inquiries"""
        # Extract order number if present
        order_patterns = [
            r'(?:order|po|#)\s*[\-#]?\s*(\d+)',
            r'(\d{5,})',  # 5+ digit numbers likely to be order numbers
        ]
        
        order_number = None
        for pattern in order_patterns:
            match = re.search(pattern, message.content.lower())
            if match:
                order_number = match.group(1)
                break
        
        if order_number:
            # TODO: Integrate with actual order system
            content = (
                f"I'm checking the status of order #{order_number}. "
                f"Your order is currently in processing and is scheduled to ship within 2-3 business days. "
                f"You'll receive tracking information via email once it ships. "
                f"Estimated delivery is 5-7 business days from ship date."
            )
        else:
            content = (
                "I'd be happy to help you check your order status. "
                "Could you please provide your order number? "
                "You can find it in your order confirmation email or invoice."
            )
        
        enhanced_content = await self.ai_service.enhance_response(message.content, content, context)
        
        return BotResponse(
            content=enhanced_content,
            suggested_actions=["Check another order", "Update delivery address", "Contact support"]
        )
    
    async def _handle_product_inquiry(self, message: CustomerMessage, context: Dict) -> BotResponse:
        """Handle product information requests"""
        # Check for specific product mentions
        product_match = re.search(r'(?:product|item|sku|model)\s*[\-#]?\s*([A-Z0-9\-]+)', message.content, re.I)
        
        if product_match:
            product_id = product_match.group(1)
            content = (
                f"I can help you with information about {product_id}. "
                f"This product is part of our industrial equipment line. "
                f"For detailed specifications and current pricing, "
                f"I can connect you with a product specialist or send you the full datasheet."
            )
        else:
            content = (
                "I can help you find product information. Our catalog includes "
                "industrial equipment, safety supplies, tools, and maintenance products. "
                "What specific product or category are you interested in? "
                "I can provide specifications, pricing, or availability information."
            )
        
        enhanced_content = await self.ai_service.enhance_response(message.content, content, context)
        
        return BotResponse(
            content=enhanced_content,
            suggested_actions=["Browse catalog", "Get quote", "Check availability", "Request datasheet"]
        )
    
    async def _handle_technical_support(self, message: CustomerMessage, context: Dict) -> BotResponse:
        """Handle technical support requests"""
        # Check urgency
        urgent_keywords = ['urgent', 'emergency', 'critical', 'asap', 'immediately']
        is_urgent = any(word in message.content.lower() for word in urgent_keywords)
        
        if is_urgent:
            escalate = True
            content = (
                "I understand this is an urgent technical issue. "
                "I'm immediately connecting you with our technical support team. "
                "A specialist will contact you within 15 minutes. "
                "For immediate assistance, you can also call our 24/7 support line at 1-800-TECH-HELP."
            )
        else:
            escalate = False
            # Try to identify the type of technical issue
            if 'install' in message.content.lower() or 'setup' in message.content.lower():
                content = (
                    "I can help with installation and setup. "
                    "Please provide the product model number and describe what step you're on. "
                    "I can guide you through the process or connect you with a technician."
                )
            else:
                content = (
                    "I'm here to help resolve your technical issue. "
                    "Could you please provide:\n"
                    "1. Product model number\n"
                    "2. Description of the problem\n"
                    "3. Any error messages you're seeing\n"
                    "This will help me provide the most accurate assistance."
                )
        
        enhanced_content = await self.ai_service.enhance_response(message.content, content, context)
        
        return BotResponse(
            content=enhanced_content,
            suggested_actions=["Describe issue", "Schedule callback", "View troubleshooting guide", "Emergency support"],
            escalate=escalate
        )
    
    async def _handle_general_query(self, message: CustomerMessage, context: Dict) -> BotResponse:
        """Handle general inquiries"""
        # Check if this is a returning customer
        if context.get("message_count", 0) > 1:
            content = (
                "Welcome back! I'm here to help with any questions you have. "
                "I can assist with:\n"
                "• Order tracking and status updates\n"
                "• Product information and pricing\n"
                "• Technical support and troubleshooting\n"
                "• Account management\n"
                "• Quote requests\n\n"
                "What can I help you with today?"
            )
        else:
            content = (
                "Hello! Welcome to our B2B support center. "
                "I'm here to help with your business needs. I can assist with:\n"
                "• Order status and tracking\n"
                "• Product information and pricing\n"
                "• Technical support\n"
                "• Quote requests\n"
                "• General inquiries\n\n"
                "How can I help you today?"
            )
        
        enhanced_content = await self.ai_service.enhance_response(message.content, content, context)
        
        return BotResponse(
            content=enhanced_content,
            suggested_actions=["Check order", "Browse products", "Get support", "Request quote"]
        )
