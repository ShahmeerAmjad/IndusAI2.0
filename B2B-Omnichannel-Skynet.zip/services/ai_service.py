# =======================
# AI Service
# =======================

from typing import Dict

from metrics.metrics import ERROR_COUNTER


try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

class AIService:
    def __init__(self, settings, logger):
        self.client = None
        self.settings = settings
        self.logger = logger
        if ANTHROPIC_AVAILABLE and settings.anthropic_api_key:
            self.client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    
    async def enhance_response(self, user_message: str, basic_response: str, context: Dict = None) -> str:
        """Enhance response with AI if available"""
        if not self.client:
            return basic_response
        
        try:
            system_prompt = """You are a helpful B2B customer service AI assistant. 
            Enhance the given response to be more professional, helpful, and actionable.
            Keep responses concise (under 150 words) and focused on solving the customer's problem.
            Maintain a professional yet friendly tone suitable for business customers."""
            
            user_prompt = f"Customer: {user_message}\n\nBasic response: {basic_response}"
            
            if context:
                user_prompt += f"\n\nContext: Customer has made {context.get('message_count', 0)} previous inquiries today."
            
            message = await self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=300,
                temperature=0.3,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}]
            )
            
            return message.content[0].text
        
        except Exception as e:
            self.logger.error(f"AI enhancement failed: {e}")
            ERROR_COUNTER.labels(error_type="ai_enhancement").inc()
            return basic_response