# =======================
# Database Manager
# =======================

import json
from typing import Dict, List, Optional
import uuid

import asyncpg
import redis.asyncio as redis

from metrics.metrics import ERROR_COUNTER
from models.models import BotResponse, CustomerMessage


class DatabaseManager:
    def __init__(self, settings, logger):
        self.settings = settings
        self.logger = logger
        self.pool: Optional[asyncpg.Pool] = None
        self.redis_client: Optional[redis.Redis] = None
    
    async def initialize(self):
        """Initialize database connections"""
        try:
            # PostgreSQL connection
            self.pool = await asyncpg.create_pool(
                self.settings.database_url,
                min_size=2,
                max_size=10,
                command_timeout=60
            )
            self.logger.info("PostgreSQL connection established")
            
            # Redis connection
            self.redis_client = redis.from_url(
                self.settings.redis_url,
                decode_responses=True
            )
            await self.redis_client.ping()
            self.logger.info("Redis connection established")
            
            # Create tables
            await self.create_tables()
            
        except Exception as e:
            self.logger.error(f"Database initialization failed: {e}")
            # Use in-memory fallback for demo
            self.pool = None
            self.redis_client = None
    
    async def create_tables(self):
        """Create required database tables"""
        if not self.pool:
            return
        
        async with self.pool.acquire() as conn:
            # Create messages table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    from_id VARCHAR(100) NOT NULL,
                    content TEXT NOT NULL,
                    channel VARCHAR(20) NOT NULL,
                    message_type VARCHAR(50),
                    confidence REAL DEFAULT 0.0,
                    timestamp TIMESTAMPTZ DEFAULT NOW(),
                    response_content TEXT,
                    response_time REAL,
                    created_at TIMESTAMPTZ DEFAULT NOW()
                )
            """)
            
            # Create customers table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS customers (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    external_id VARCHAR(100) UNIQUE NOT NULL,
                    name VARCHAR(255),
                    email VARCHAR(255),
                    phone VARCHAR(50),
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    last_activity TIMESTAMPTZ DEFAULT NOW()
                )
            """)
            
            # Create indexes for performance
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages(timestamp DESC)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_from_id ON messages(from_id)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_type_timestamp ON messages(message_type, timestamp DESC)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_customers_external_id ON customers(external_id)")
    
    async def save_message(self, message: CustomerMessage, response: BotResponse, response_time: float):
        """Save message and response to database"""
        if not self.pool:
            self.logger.warning("No database connection - skipping message save")
            return
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO messages 
                    (id, from_id, content, channel, message_type, confidence, response_content, response_time, timestamp)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """, 
                    str(uuid.uuid4()),
                    message.from_id[:100],  # Ensure length limit
                    message.content[:1000],  # Ensure length limit
                    message.channel.value,
                    message.message_type.value,
                    float(message.confidence),
                    response.content[:5000],  # Limit response size
                    float(response_time),
                    message.timestamp
                )
        except Exception as e:
            self.logger.error(f"Failed to save message: {e}")
            ERROR_COUNTER.labels(error_type="database_save").inc()
    
    async def get_recent_messages(self, limit: int = 50) -> List[Dict]:
        """Get recent messages for admin dashboard"""
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT from_id, content, channel, message_type, confidence, 
                           response_content, response_time, timestamp
                    FROM messages 
                    ORDER BY timestamp DESC 
                    LIMIT $1
                """, limit)
                
                return [dict(row) for row in rows]
        except Exception as e:
            self.logger.error(f"Failed to get recent messages: {e}")
            return []
    
    async def get_customer_session(self, customer_id: str) -> Optional[Dict]:
        """Get customer session from Redis"""
        if not self.redis_client:
            return None
        
        try:
            session_data = await self.redis_client.get(f"session:{customer_id}")
            if session_data:
                return json.loads(session_data)
        except Exception as e:
            self.logger.error(f"Failed to get session: {e}")
        
        return None
    
    async def save_customer_session(self, customer_id: str, session_data: Dict):
        """Save customer session to Redis"""
        if not self.redis_client:
            return
        
        try:
            await self.redis_client.setex(
                f"session:{customer_id}",
                3600,  # 1 hour TTL
                json.dumps(session_data)
            )
        except Exception as e:
            self.logger.error(f"Failed to save session: {e}")
    
    async def close(self):
        """Close database connections"""
        if self.pool:
            await self.pool.close()
        if self.redis_client:
            await self.redis_client.close()
