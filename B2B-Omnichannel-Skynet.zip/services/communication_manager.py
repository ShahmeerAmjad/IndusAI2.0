# =======================
# Communication Manager
# =======================

import asyncio
from typing import List
import httpx

from metrics.metrics import ERROR_COUNTER


class CommunicationManager:
    def __init__(self, logger, settings):
        self.logger = logger
        self.settings = settings
        self.whatsapp_client = httpx.AsyncClient(timeout=30.0)
    
    async def send_whatsapp_message(self, to_id: str, content: str, suggested_actions: List[str] = None) -> bool:
        """Send WhatsApp message with retry logic"""
        if not all([self.settings.whatsapp_access_token, self.settings.whatsapp_phone_number_id]):
            self.logger.warning(f"WhatsApp not configured - would send to {to_id}: {content[:50]}...")
            return True
        
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                url = f"{self.settings.whatsapp_api_url}/{self.settings.whatsapp_phone_number_id}/messages"
                headers = {
                    "Authorization": f"Bearer {self.settings.whatsapp_access_token}",
                    "Content-Type": "application/json"
                }
                
                # Build message data
                data = {
                    "messaging_product": "whatsapp",
                    "to": to_id,
                    "type": "text",
                    "text": {"body": content}
                }
                
                # Add interactive buttons if suggested actions provided
                if suggested_actions and len(suggested_actions) <= 3:
                    data["type"] = "interactive"
                    data["interactive"] = {
                        "type": "button",
                        "body": {"text": content},
                        "action": {
                            "buttons": [
                                {
                                    "type": "reply",
                                    "reply": {"id": f"action_{i}", "title": action[:20]}
                                }
                                for i, action in enumerate(suggested_actions[:3])
                            ]
                        }
                    }
                
                response = await self.whatsapp_client.post(url, json=data, headers=headers)
                response.raise_for_status()
                
                self.logger.info(f"WhatsApp message sent successfully to {to_id}")
                return True
                
            except httpx.HTTPStatusError as e:
                self.logger.error(f"WhatsApp API error (attempt {attempt + 1}): {e.response.status_code} - {e.response.text}")
                if e.response.status_code == 429:  # Rate limit
                    retry_delay *= 2  # Exponential backoff
                elif e.response.status_code >= 500:  # Server error
                    pass  # Retry
                else:
                    break  # Don't retry client errors
                    
            except Exception as e:
                self.logger.error(f"WhatsApp send failed (attempt {attempt + 1}): {e}")
            
            if attempt < max_retries - 1:
                await asyncio.sleep(retry_delay)
        
        ERROR_COUNTER.labels(error_type="whatsapp_send").inc()
        return False
    
    async def close(self):
        """Close HTTP clients"""
        await self.whatsapp_client.aclose()