# =======================
# Intent Classification
# =======================

import re
from typing import Tuple
from models.models import MessageType
from fuzzywuzzy import fuzz

class IntentClassifier:
    def __init__(self):
        self.patterns = {
            MessageType.ORDER_STATUS: [
                r'(?:status|track|where).*(?:order|po|shipment|purchase)',
                r'order.*(?:status|tracking|number)',
                r'(?:po|order|#)[\s-]?\d+',
                r'delivery.*(?:status|date|time)',
                r'when.*(?:arrive|deliver|ship)'
            ],
            MessageType.PRODUCT_INQUIRY: [
                r'(?:product|item|sku).*(?:info|detail|spec|price)',
                r'tell.*about.*(?:product|item)',
                r'(?:price|cost|pricing|quote)',
                r'(?:availability|stock|inventory)',
                r'(?:catalog|catalogue)'
            ],
            MessageType.TECHNICAL_SUPPORT: [
                r'(?:help|support|issue|problem|trouble)',
                r'(?:not|doesn\'t|won\'t).*(?:work|working|function)',
                r'(?:error|failure|broken|defect)',
                r'technical.*(?:support|help|assistance)',
                r'(?:install|setup|configure)'
            ]
        }
        
        # Spam patterns for filtering
        self.spam_patterns = [
            r'(?:viagra|cialis|casino|lottery|winner)',
            r'(?:click here|limited time|act now)',
            r'(?:million dollars|inheritance|prince)'
        ]
    
    def classify(self, text: str) -> Tuple[MessageType, float]:
        """Classify message intent"""
        text_lower = text.lower().strip()
        
        # Check for spam first
        if self._is_spam(text_lower):
            return MessageType.UNKNOWN, 0.0
        
        best_type = MessageType.UNKNOWN
        best_confidence = 0.0
        
        # Pattern matching
        for msg_type, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_lower):
                    confidence = 0.85
                    if confidence > best_confidence:
                        best_type = msg_type
                        best_confidence = confidence
        
        # Fuzzy matching fallback
        if best_confidence < 0.5:
            fuzzy_type, fuzzy_conf = self._fuzzy_classify(text_lower)
            if fuzzy_conf > best_confidence:
                best_type = fuzzy_type
                best_confidence = fuzzy_conf
        
        return best_type, best_confidence
    
    def _fuzzy_classify(self, text: str) -> Tuple[MessageType, float]:
        """Fuzzy matching fallback"""
        examples = {
            MessageType.ORDER_STATUS: [
                "order status", "track order", "shipment tracking", 
                "where is my order", "delivery date"
            ],
            MessageType.PRODUCT_INQUIRY: [
                "product info", "pricing", "availability", 
                "tell me about", "product details", "in stock"
            ],
            MessageType.TECHNICAL_SUPPORT: [
                "help", "support", "problem", "not working", 
                "technical issue", "error", "broken"
            ]
        }
        
        best_type = MessageType.UNKNOWN
        best_score = 0.0
        
        for msg_type, example_list in examples.items():
            for example in example_list:
                score = fuzz.partial_ratio(text, example) / 100.0
                if score > best_score and score > 0.6:
                    best_score = score * 0.8  # Scale down fuzzy match confidence
                    best_type = msg_type
        
        return best_type, best_score
    
    def _is_spam(self, text: str) -> bool:
        """Check if message is spam"""
        for pattern in self.spam_patterns:
            if re.search(pattern, text):
                return True
        return False