# B2B AI Chatbot MVP -- Complete File Package (v1.1.0)

## 📌 Overview

This is the **production-ready** file package for the **B2B AI Chatbot
MVP**.\
The project is structured to ensure scalability, maintainability, and
modularity for future development.

------------------------------------------------------------------------

## 📁 File Structure

    b2b-chatbot-mvp/
    ├── main.py                  # Main application entry point
    ├── requirements.txt         # Python dependencies
    ├── .env.example             # Environment variable template
    ├── metrices/                # Metrics-related logic
    │   └── metrices.py          # Contains all chatbot metrics
    ├── models/                  # Data models
    │   └── models.py            # Defines all project models
    ├── services/                # Service layer for core functionalities
    │   ├── ai_service.py        # AI interaction logic
    │   ├── business_logic.py    # Business rules and workflow handling
    │   ├── chatbot_engine.py    # Main chatbot engine for conversation flow
    │   ├── communication_manager.py # Manages communication channels
    │   ├── database_manager.py  # Handles database operations
    │   └── intent_classifier.py # Classifies user intents

------------------------------------------------------------------------

## 🚀 Getting Started

### 1. Clone the Repository

``` bash
git clone https://github.com/your-username/b2b-chatbot-mvp.git
cd b2b-chatbot-mvp
```

### 2. Install Dependencies

``` bash
pip install -r requirements.txt
```

### 3. Configure Environment

Copy the `.env.example` file and update the environment variables:

``` bash
cp .env.example .env
```

### 4. Run the Application

``` bash
python runserver main.py
```

------------------------------------------------------------------------

## 🛠 Tech Stack

-   **Python 3.9+**
-   AI/ML libraries (for chatbot intelligence)
-   Database layer (managed by `database_manager.py`)
-   Modular services for business logic and intent classification

------------------------------------------------------------------------

## 🔑 Key Features

-   Clean and modular service layer
-   Metrics tracking for chatbot performance
-   Intent classification and business logic separation
-   Scalable architecture for B2B AI solutions
